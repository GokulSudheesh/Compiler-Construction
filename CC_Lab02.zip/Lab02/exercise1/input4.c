#include<stdio.h>
int mine[]
(
}
