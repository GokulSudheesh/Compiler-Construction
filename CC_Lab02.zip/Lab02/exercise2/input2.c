#include<stdio.h>
int main()
{
	int var1,var2,var3;
}
