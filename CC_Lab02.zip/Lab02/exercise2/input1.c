#include<stdio.h>
int main()
{
	int varone,vartwo,varthree;
}
