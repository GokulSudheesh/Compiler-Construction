#include<stdio.h>
int main()
{
	int var,varone,two;
	int teeone,teetwo,;	
}
